const { Router } = require('express');

const authRoutes = require('./auth.routes');
const tarefaRoutes = require('./tarefa.routes');

const router = Router();

router.use('/auth', authRoutes);
router.use('/tarefas', tarefaRoutes);

module.exports = router;