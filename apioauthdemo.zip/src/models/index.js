import sequelize from "../config/database.js";
import User from "./user.js";
import Note from "./note.js";

User.hasMany(Note, { foreignKey: "userId", onDelete: "CASCADE" });
Note.belongsTo(User, { foreignKey: "userId" });

export { sequelize, User, Note };