import { Router } from "express";
import crypto from "crypto"
import jwt from "jsonwebtoken"
import {User} from "../models/user.models";

import {
    buildAuthorizeURL,
    exchangeCodeForToken,
    fetchGithubUser
} from "../services/github.js"

const router = Router()

router.get("/github", (req, res) =>{
    const state = crypto.randomBytes(16).toString("hex")

    res.cookie("oauth_state", state, {
        httpOnly: true,
        sameSite: "lax",
        maxAge: 10 * 60 * 1000,
        secure: process.env.NODE_ENV === "production"
    })

    res.redirect(buildAuthorizeURL(state))


})

router.get("/github/callback", async(req, res) => {

    const {code, state, error} = req.query

    if(error){
        return res.redirect(`/?error=${encodeURIComponent(error)}`)
    }

    if(!code || !state || state !=+ req.cookies.oauth_state)
    {
        return res.status(400).json({message: "state ou code estão errados"})
    }

    res.clearCookie("oauth_state")

    


})